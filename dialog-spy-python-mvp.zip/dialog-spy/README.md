# Dialog Spy

Стартовый Python-репозиторий сервиса архива Telegram Business.

## Стек

- Python 3.12
- FastAPI + Uvicorn
- aiogram 3
- SQLAlchemy async + Alembic
- PostgreSQL
- Redis
- отдельный Python worker
- Docker Compose
- статический Telegram Mini App с единым navigation state

## Что реализовано в версии 0.1.0

- HTTPS-ready webhook endpoint с secret path/header.
- Приём `message`, `callback_query`, `business_connection`, `business_message`, `edited_business_message`, `deleted_business_messages`.
- Дедупликация по уникальному `update_id`.
- Регистрация `/start`, однократный 72-часовой trial, повторный `/start` без продления.
- Referral-модель с запретом повторной привязки и однократным бонусом 72 часа.
- Business connections, dialogs, messages, versions, deletion flags и media metadata.
- Контракт: обычные сообщения и обычные медиа не пересылаются владельцу.
- Уведомления edit/delete/connection через устойчивую DB-backed очередь.
- Повторная проверка `media.is_protected is True` непосредственно в worker перед отправкой.
- Mini App auth через проверку Telegram `initData`; новый access token при каждом запуске.
- Список диалогов, экран диалога, профиль, настройки, retry/error state.
- Один route state, один `popstate`, один Telegram BackButton handler, защита от устаревших async responses.
- Команды `/start`, `/app`, `/help`, `/status`, `/privacy`, `/admin`.
- PostgreSQL/Redis health endpoints, structured logging, correlation IDs.
- Docker Compose, CI, backup script и базовые тесты.

## Осознанно оставлено следующими инкрементами

Стартовый архив — не обещание production-ready системы. Перед запуском за деньги необходимо добавить:

- полноценную web-admin авторизацию, refresh rotation, dashboard и CRUD;
- мастер рассылок и snapshot recipients;
- S3-compatible storage и signed media URLs;
- внешний платежный provider;
- admin audit во всех административных операциях;
- Prometheus/Sentry/alerts;
- юридические тексты и реальные help-видео;
- Telegram E2E с несколькими реальными аккаунтами;
- нагрузочные и restore tests;
- точную проверку доступности disappearing/protected media для конкретной версии Bot API.

## Быстрый запуск

```bash
cp .env.example .env
# заполните TELEGRAM_BOT_TOKEN, домены и секреты
docker compose up -d --build
python scripts/set_webhook.py
```

API: `http://localhost:8000/docs`

Health:

```bash
curl http://localhost:8000/health/live
curl http://localhost:8000/health/ready
```

## Важные production-правила

- Никогда не выполнять `docker compose down -v` при обычном обновлении.
- Не хранить реальные секреты в Git.
- Reverse proxy должен завершать HTTPS и проксировать `/telegram/webhook/*`, `/api/*`, `/app`, `/admin`.
- Перед релизом заменить query-version assets на реальный content hash сборки.
- Проверять восстановление backup в отдельном окружении.

## GitHub workflow

```bash
git init
git add .
git commit -m "feat: bootstrap Dialog Spy"
git branch -M main
git remote add origin <YOUR_REPOSITORY_URL>
git push -u origin main
```

## Архитектурное замечание о protected media

Telegram Bot API передаёт признак защищённого контента через данные сообщения, но фактическая возможность скачать одноразовый файл зависит от того, что Telegram реально передал боту и когда. Поэтому данный репозиторий не подделывает содержимое и не маркирует любое reply-медиа как protected. Worker отправляет файл только при сохранённом `is_protected=true`; это дополнительный safety invariant.
