const tg = window.Telegram?.WebApp;
const root = document.querySelector('#root');
const back = document.querySelector('#back');
const profile = document.querySelector('#profile');
let token = null;
let state = {route: 'dialogs', params: {}};
let requestVersion = 0;

function expand() {
  try { tg?.ready(); tg?.expand(); tg?.requestFullscreen?.(); } catch (_) {}
}
expand();
tg?.onEvent?.('viewportChanged', expand);

function navigate(route, params = {}, replace = false) {
  state = {route, params};
  const url = new URL(location.href);
  url.searchParams.set('screen', route);
  if (params.id) url.searchParams.set('id', params.id); else url.searchParams.delete('id');
  history[replace ? 'replaceState' : 'pushState'](state, '', url);
  render();
}

function goBack() {
  if (state.route === 'dialog') return navigate('dialogs');
  if (state.route === 'settings') return navigate('profile');
  if (state.route !== 'dialogs') return history.back();
  tg?.close?.();
}

back.addEventListener('click', goBack);
tg?.BackButton?.onClick(goBack);
window.addEventListener('popstate', (event) => {
  state = event.state || {route: 'dialogs', params: {}};
  render();
});
profile.addEventListener('click', () => navigate('profile'));

async function api(path) {
  const response = await fetch(path, {headers: {Authorization: `Bearer ${token}`}});
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json();
}

function setBackVisibility() {
  const visible = state.route !== 'dialogs';
  back.hidden = !visible;
  if (visible) tg?.BackButton?.show(); else tg?.BackButton?.hide();
}

async function render() {
  setBackVisibility();
  const current = ++requestVersion;
  root.innerHTML = '<div class="loader">Загрузка…</div>';
  try {
    if (state.route === 'dialogs') {
      const data = await api('/api/dialogs'); if (current !== requestVersion) return;
      root.innerHTML = `<input id="search" placeholder="Поиск"><div id="list">${data.items.map(d => `<article class="card" data-id="${d.id}"><b>${escapeHtml(d.peer_name || 'Без имени')}</b><div class="muted">${escapeHtml(d.peer_username || '')}</div></article>`).join('') || '<div class="card">Диалогов пока нет</div>'}</div>`;
      root.querySelectorAll('[data-id]').forEach(el => el.onclick = () => navigate('dialog', {id: Number(el.dataset.id)}));
    } else if (state.route === 'dialog') {
      const data = await api(`/api/dialogs/${state.params.id}`); if (current !== requestVersion) return;
      root.innerHTML = `<h2>${escapeHtml(data.dialog.peer_name || 'Диалог')}</h2>${data.messages.map(m => `<div class="message ${m.direction} ${m.is_deleted ? 'deleted' : ''}">${escapeHtml(m.text || m.caption || (m.media.length ? `[${m.media[0].type}]` : ''))}<div class="muted">${new Date(m.sent_at).toLocaleString()} ${m.edited_at ? '· изменено' : ''} ${m.is_deleted ? '· удалено' : ''}</div></div>`).join('')}`;
    } else if (state.route === 'profile') {
      const me = await api('/api/me'); if (current !== requestVersion) return;
      root.innerHTML = `<div class="card"><h2>${escapeHtml([me.first_name, me.last_name].filter(Boolean).join(' ') || 'Профиль')}</h2><p>@${escapeHtml(me.username || '—')}</p><p>Telegram ID: ${me.telegram_id}</p><p>Business: ${me.business_connected ? 'подключён' : 'не подключён'}</p><p>Доступ до: ${new Date(me.access_ends_at).toLocaleString()}</p></div><button id="settings">Настройки</button><div class="card"><b>Подписка</b><p>Оплата временно недоступна. Администратор может выдать VIP.</p></div>`;
      document.querySelector('#settings').onclick = () => navigate('settings');
    } else if (state.route === 'settings') {
      const s = await api('/api/settings'); if (current !== requestVersion) return;
      root.innerHTML = `<h2>Настройки</h2>${Object.entries(s).map(([k,v]) => `<div class="card row"><span>${escapeHtml(k)}</span><span>${escapeHtml(String(v))}</span></div>`).join('')}`;
    }
  } catch (error) {
    if (current !== requestVersion) return;
    root.innerHTML = `<div class="error"><h2>Не удалось подключиться к серверу</h2><button id="retry">Повторить</button></div>`;
    document.querySelector('#retry').onclick = render;
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}

async function boot() {
  if (!tg?.initData) {
    root.innerHTML = '<div class="error"><h2>Откройте приложение через Telegram-бота.</h2></div>';
    return;
  }
  try {
    const response = await fetch('/api/auth/telegram', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({init_data:tg.initData})});
    if (!response.ok) throw new Error('auth failed');
    token = (await response.json()).access_token;
    history.replaceState(state, '', location.href);
    await render();
  } catch (_) {
    root.innerHTML = '<div class="error"><h2>Не удалось подключиться к серверу.</h2><button id="retry">Повторить</button></div>';
    document.querySelector('#retry').onclick = boot;
  }
}
boot();
