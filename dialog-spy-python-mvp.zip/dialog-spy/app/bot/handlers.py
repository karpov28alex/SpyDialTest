from datetime import UTC, datetime

from aiogram import F, Router
from aiogram.filters import Command, CommandObject
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message, WebAppInfo
from sqlalchemy import func, select

from app.bot.setup import bot
from app.core.config import get_settings
from app.db.models import BusinessConnection, FailedUpdate, User
from app.db.session import SessionLocal
from app.services.access import access_ends_at, refresh_subscription_status
from app.services.users import referral_code, register_or_update_user

router = Router(name="commands")
settings = get_settings()


def app_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="Открыть Dialog Spy", web_app=WebAppInfo(url=settings.mini_app_url))]]
    )


@router.message(Command("start"))
async def start(message: Message, command: CommandObject) -> None:
    if not message.from_user:
        return
    async with SessionLocal() as session, session.begin():
        _, created = await register_or_update_user(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name,
            last_name=message.from_user.last_name,
            language_code=message.from_user.language_code,
            start_parameter=command.args,
        )
    greeting = (
        "Добро пожаловать в <b>Dialog Spy</b>.\n\n"
        "Сервис сохраняет историю Telegram Business переписки, удалённые и изменённые "
        "сообщения, а также поддерживаемые защищённые медиа.\n\n"
        "Подключите Telegram Business и откройте Mini App для просмотра архива."
    )
    await message.answer(greeting, reply_markup=app_keyboard())
    if created:
        await message.answer(
            "Продолжая использование сервиса, вы принимаете условия оферты и политики конфиденциальности."
        )


@router.message(Command("app"))
async def app_command(message: Message) -> None:
    await message.answer("Откройте архив Dialog Spy:", reply_markup=app_keyboard())


@router.message(Command("help"))
async def help_command(message: Message) -> None:
    await message.answer(
        "<b>Как подключить Telegram Business</b>\n\n"
        "1. Откройте Настройки Telegram.\n"
        "2. Перейдите в Telegram Business → Чат-боты.\n"
        "3. Выберите Dialog Spy и выдайте необходимые права.\n"
        "4. Сохраните подключение.\n\n"
        "Защищённое медиа: не открывайте его, ответьте на сообщение любым текстом. "
        "Система обработает только медиа, которое Telegram пометил как защищённое."
    )


@router.message(Command("status"))
async def status_command(message: Message) -> None:
    if not message.from_user:
        return
    async with SessionLocal() as session, session.begin():
        user = await session.scalar(select(User).where(User.telegram_id == message.from_user.id).with_for_update())
        if not user:
            await message.answer("Сначала выполните /start")
            return
        status = refresh_subscription_status(user)
        connection = await session.scalar(
            select(BusinessConnection).where(
                BusinessConnection.owner_user_id == user.id,
                BusinessConnection.is_active.is_(True),
            )
        )
        ends_at = access_ends_at(user)
    await message.answer(
        f"Business: {'подключён' if connection else 'не подключён'}\n"
        f"Статус: {status.value}\n"
        f"Доступ до: {ends_at.astimezone(UTC).strftime('%d.%m.%Y %H:%M UTC')}"
    )


@router.message(Command("privacy"))
async def privacy_command(message: Message) -> None:
    await message.answer(
        "Политика конфиденциальности и оферта будут опубликованы на рабочем домене.\n"
        "Для экспорта или удаления данных обратитесь в поддержку."
    )


@router.message(Command("admin"))
async def admin_command(message: Message) -> None:
    if not message.from_user or message.from_user.id not in settings.telegram_admin_ids:
        await message.answer("Команда недоступна.")
        return
    async with SessionLocal() as session:
        total = await session.scalar(select(func.count(User.id))) or 0
        active_connections = await session.scalar(
            select(func.count(BusinessConnection.id)).where(BusinessConnection.is_active.is_(True))
        ) or 0
        errors = await session.scalar(
            select(func.count(FailedUpdate.id)).where(FailedUpdate.resolved.is_(False))
        ) or 0
    await message.answer(
        f"<b>Dialog Spy Admin</b>\n\nПользователей: {total}\n"
        f"Business-подключений: {active_connections}\nОшибок: {errors}\n"
        f"Версия: {settings.app_version} · {settings.git_sha}"
    )


@router.message(F.text.startswith("/"))
async def unknown_command(message: Message) -> None:
    await message.answer("Неизвестная команда. Доступны: /start, /app, /help, /status, /privacy")
